# VeluneOS Compare — Beta Quickstart

Welcome. This guide gets you from two robotics logs to a structural
comparison report.

## What VeluneOS Compare does

VeluneOS Compare takes two runs — a **Reference Run** and a **Target
Run** — and shows you what changed between them, structurally: which
systems differ, and where to look first.

VeluneOS identifies comparative observations. Engineers determine the
cause.

- **Reference Run**: the run you're using as your comparison basis.
- **Target Run**: the run you're comparing against it.

Reference does not mean "normal" or "correct" — it's simply the
baseline you chose. Either run could be the one with the problem.

## Raw logs stay local

Your raw MCAP files never leave your machine. Velune Adapter reads your
MCAP files locally and produces one small, derived file —
`comparison.velune` — containing only structural information (topic
presence, timing, canonical categories). That file is the only thing you
upload.

## 1. Create a Python environment

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Requires Python 3.12 or 3.13.

## 2. Install Velune Adapter

The Velune Adapter Beta Kit includes two Python packages required for
the customer workflow. Install both:

```bash
pip install velune_adapter-0.2.0-py3-none-any.whl velune_local_prepare-0.1.1b5-py3-none-any.whl
```

You use one command: `velune`.

## 3. Verify the install

```bash
velune --help
```

You should see `mapping` and `prepare` listed as subcommands.

## 4. Discover your streams

```bash
velune mapping init reference.mcap target.mcap --output mapping.json
```

This reads both MCAP files locally and writes `mapping.json` — a small,
plain JSON file listing every stream found in your Reference and Target
runs, and how Velune Adapter will pair them across the two runs.

## 5. What mapping.json means

Each entry in `mapping.json` looks like this:

```json
{
  "raw_match_key": "/your/topic/name",
  "canonical_subsystem_id": null,
  "canonical_category_id": null,
  "_presence": "both"
}
```

`raw_match_key` is the topic VeluneOS found. `_presence` tells you
whether it appeared in the Reference run, the Target run, or both.
`canonical_subsystem_id` / `canonical_category_id` are left blank —
that's the one thing you fill in. The categories you assign are how you
recognise your streams in the report, which otherwise names them only by
neutral keys such as `stream.unmapped.003`.

## 6. Complete the mapping

Assign categories to the streams you want to recognise in the report
(at least one is required), setting:

- `canonical_subsystem_id` — the general system area, e.g. `PERCEPTION`,
  `LOCALIZATION`, `PLANNING`, `COMMAND_CONTROL`, `MOTION`
- `canonical_category_id` — the specific category, e.g.
  `PERCEPTION_LIDAR`, `LOCALIZATION_GNSS`

A stream left as-is (both fields `null`) is **still compared**: VeluneOS
Compare compares every stream in `comparison.velune` and shows an
unassigned stream by its neutral key only. Its structural summary
(message counts, timing) is in `comparison.velune` either way, as the
transfer preview (step 8) shows.

## 6a. Confirm stream pairings

Velune Adapter pairs a Reference stream with a Target stream when their
topic names are identical. When a topic exists in only one run, it may
instead pair it with a leftover topic of the **same message type** in the
other run — for example `/camera/left` (Reference) with `/camera/rear`
(Target). That is correct for a renamed topic and wrong for a different
sensor. Comparing two different sensors would report a change that did
not happen.

Every pairing that is not based on an identical, unique topic name is
listed under `correspondence_review` in `mapping.json`:

```json
"correspondence_review": [
  {
    "reference_topic": "/camera/left",
    "target_topic": "/camera/rear",
    "reference_channel_id": 2,
    "target_channel_id": 2,
    "basis": "matched_by_message_type",
    "same_stream": null
  }
]
```

Set `"same_stream": true` only if the two really are the same stream.
`velune prepare` refuses to continue while any entry is `null`. If you set
`false`, this kit cannot prepare the pair for comparison yet and stops
without producing a file — contact contact@veluneos.ai. The list is empty
in the usual case where every stream keeps its topic name.
`comparison.velune` records only the basis of each pairing (stream key and
`same_topic_name`, `customer_confirmed_same_stream`, `reference_only` or
`target_only`), never topic names.

## 7. Prepare the comparison artifact

```bash
velune prepare reference.mcap target.mcap \
  --mapping-profile mapping.json \
  --output comparison.velune
```

This produces `comparison.velune` plus one companion file,
`comparison.preview.json`, describing exactly what is in the final
archive. It tells you where both are and what to do next:

```
Velune Adapter — preparation complete
Artifact: /path/to/comparison.velune
Transfer ID: vtransfer_sha256_...
Transfer preview: /path/to/comparison.preview.json (N files in
comparison.velune, N bytes -- raw MCAP, payloads, original paths/topic/
schema names, and absolute timestamps are not included; see the file
for the full list of what is)

Next: review the transfer preview, then upload this file to VeluneOS Compare
https://compare.veluneos.ai/compare
```

If the artifact is created but its preview cannot be, `prepare` prints
"Velune Adapter — preparation incomplete" and a warning instead, and
exits with a non-zero status. Do not upload `comparison.velune` in that
case until you can review it.

## 8. Review what will be uploaded

Open `comparison.preview.json` before you upload anything. It lists
every entry actually inside `comparison.velune`, its size and hash, and
an explicit `explicitly_excluded_categories` list confirming raw MCAP,
raw or decoded payloads, original file/topic/schema names, absolute
timestamps, and credentials are not present. Its `streams` list also
shows every stream still present in the transfer, including ones you
excluded from the comparison in step 6 — `included_in_canonical_comparison:
false` means "not compared", not "not transferred". This file itself is
never uploaded — it is only for you to read locally.

## 9. Open VeluneOS Compare

Go to **https://compare.veluneos.ai/compare** (you'll need the Beta
access credentials sent with your kit).

## 10. Upload

Drop `comparison.velune` onto the page.

## 11. Inspect the structural differences

The report starts with one decision — `REVIEW_REQUIRED`,
`NO_MATERIAL_STRUCTURAL_CHANGE`, `INCONCLUSIVE_DIFFERENCE` or
`INSUFFICIENT_COVERAGE` — then lists the differences to review in order:
streams present in only one run, longer or shorter message intervals,
activity that stops and whether it recovers, and timestamp
representation changes. Each has a time window and an evidence quality
(comparable, limited or inconclusive).

Above the report, **Your stream categories** maps each neutral stream key
to the categories you assigned and shows how it was paired: identical
topic name, your confirmation, or present in one run only. If a key shows
different Reference and Target categories, check that pairing again.

The service processes the file in a temporary directory that is deleted
when the report is returned. Nothing is stored on the server.

## 12. Download your report

Use the download buttons to save the report (HTML or Markdown),
`comparison_report.json` (schema 0.5.0), the summary, and
`stream_categories.json`.

## Troubleshooting

- **`velune: command not found`** — make sure your virtual environment
  is activated (`source .venv/bin/activate`) and that both wheels
  installed without error.
- **"Velune Adapter is not installed"** — install both wheels from the
  Beta Kit together; `velune-local-prepare` depends on `velune-adapter`.
- **A mapping rule fails validation** — every rule needs both
  `canonical_subsystem_id` and `canonical_category_id` set together (or
  both left `null`) — one filled in without the other will fail closed.
- **`prepare` stops with "cannot tell whether they are the same stream"**
  — answer every `correspondence_review` entry (step 6a). If your
  `mapping.json` has no `correspondence_review` section, it was made by an
  older kit: run `velune mapping init` again.
- **VeluneOS Compare says the file was prepared with an older Beta Kit**
  — install this kit (0.1.1b5) and run `velune prepare` again.
- **Nothing happens after `prepare`** — check that `mapping.json` is
  valid JSON and that every rule you intend to compare has both
  canonical fields filled in.
