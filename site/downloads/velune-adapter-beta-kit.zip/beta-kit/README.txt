Velune Adapter — Beta Kit
==========================

This kit installs Velune Adapter, the customer-local tool that turns a
Reference run and a Target run into one comparison.velune file for
VeluneOS Compare.

Contents:
  velune_adapter-0.2.0-py3-none-any.whl          <- Velune Adapter package
  velune_local_prepare-0.1.1b4-py3-none-any.whl  <- Velune Adapter package
  BETA_QUICKSTART.md   <- start here
  SHA256SUMS           <- verify both wheels before installing

The Velune Adapter Beta Kit includes two Python packages required for
the customer workflow. Install both; you use one command: velune.

Verify:
  sha256sum -c SHA256SUMS

Install:
  python3 -m venv .venv
  source .venv/bin/activate
  pip install velune_adapter-0.2.0-py3-none-any.whl velune_local_prepare-0.1.1b4-py3-none-any.whl
  velune --help

Then follow BETA_QUICKSTART.md.

Raw MCAP logs never leave your machine. Only the prepared
comparison.velune file is uploaded, to https://compare.veluneos.ai/compare.

Questions: contact@veluneos.ai
