Velune Adapter — Beta Kit
==========================

This kit installs Velune Adapter, the customer-local tool that turns a
Reference run and a Target run into one comparison.velune file for
VeluneOS Compare.

Contents:
  velune_adapter-0.2.0-py3-none-any.whl          <- Velune Adapter package
  velune_local_prepare-0.1.1b6-py3-none-any.whl  <- Velune Adapter package
  BETA_QUICKSTART.md   <- start here
  SHA256SUMS           <- verify both wheels before installing

The Velune Adapter Beta Kit includes two Python packages required for
the customer workflow. Install both; you use one command: velune.

Verify:
  sha256sum -c SHA256SUMS

Install:
  python3 -m venv .venv
  source .venv/bin/activate
  pip install velune_adapter-0.2.0-py3-none-any.whl velune_local_prepare-0.1.1b6-py3-none-any.whl
  velune --help

Then follow BETA_QUICKSTART.md.

Raw MCAP logs never leave your machine. The only file meant to leave it
is the prepared comparison.velune. It contains no raw data, payloads,
original topic/file names or absolute timestamps, but that alone does
not make it anonymous: it still carries per-stream counts and timing,
the category text you type, and each raw file's size. Review
comparison.preview.json before sharing it.

Hosted service: upload comparison.velune to https://compare.veluneos.ai/compare.
If you agreed a separate review with VeluneOS instead, do not upload:
send the file only through the channel agreed with VeluneOS.

Questions: contact@veluneos.ai
